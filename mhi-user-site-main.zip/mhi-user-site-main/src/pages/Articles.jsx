// import React, { useCallback, useEffect, useRef, useState } from "react";
// import FilterSidebar from "../components/FilterSidebar/FilterSidebar";
// import SearchBar from "../components/SearchBar/SearchBar";
// import StudyCard from "../components/StudyCard/StudyCard";
// import axios from "axios";
// import { Oval } from "react-loader-spinner";
// import { useLocation, useNavigate } from "react-router-dom";
// import { additionalFilters } from "../utils/constants";
// import { transformFilters } from "../utils/helpers";
// import { apiHandle } from "../config/apiHandle/apiHandle";
// import NoDataFound from "../components/NoDataFound/NoDataFound";

// const Articles = () => {
//   const navigate = useNavigate();
//   const location = useLocation();

//   const [searchTerm, setSearchTerm] = useState("");
//   const [selectedYear, setSelectedYear] = useState("");
//   const [studies, setStudies] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const [filters, setFilters] = useState([]);
//   const [page, setPage] = useState(1);
//   const [hasMore, setHasMore] = useState(true);
//   const [selectedFilters, setSelectedFilters] = useState({});
//   const [sortOrder, setSortOrder] = useState("newest"); // "newest" or "oldest"
//   const [isLoadingMore, setIsLoadingMore] = useState(false);
//   const [totalArticles, setTotalArticles] = useState(0);
//   const [isSearchActive, setIsSearchActive] = useState(false);
//   const [searchResults, setSearchResults] = useState([]);
//   const [debouncedSearchTerm, setDebouncedSearchTerm] = useState("");

//   const abortControllerRef = useRef(null);
//   useEffect(() => {
//     // Parse URL parameters when component loads
//     const searchParams = new URLSearchParams(location.search);
//     const params = {};
//     //  if (searchParams) {
//     //     setSearchTerm(searchParams);
//     //  }
//     // Map URL parameters to request body fields
//     const paramMappings = {
//       study: "studyType",
//       specie: "species",
//       researchTopic: "researchtopic",
//       organ: "organ",
//       year: "year",
//       author: "admin_search",
//       marker: "marker",
//       category: "category",
//       authors: "authors",
//       country: "country",
//       system: "system",
//       administration_methods: "administration_methods",
//     };

//     // Iterate through all search parameters
//     searchParams.forEach((value, key) => {
//       if (paramMappings[key]) {
//         const mappedKey = paramMappings[key];
//         if (
//           [
//             "studyType",
//             "species",
//             "researchtopic",
//             "organ",
//             "marker",
//             "category",
//             "authors",
//             "country",
//             "system",
//             "administration_methods",
//           ].includes(mappedKey)
//         ) {
//           params[mappedKey] = searchParams.getAll(key);
//         } else if (["year", "admin_search"].includes(mappedKey)) {
//           params[mappedKey] = value;
//         }
//       }
//     });

//     // Update selected filters with parsed params
//     setSelectedFilters((prev) => ({
//       ...prev,
//       ...params,
//     }));
//   }, [location.search]);
//   // Memoized fetch function
//   const fetchStudies = useCallback(
//     async (pageNumber = 1, searchQuery = debouncedSearchTerm) => {
//       try {
//         // Cancel previous request
//         if (abortControllerRef.current) {
//           abortControllerRef.current.abort();
//         }
//         abortControllerRef.current = new AbortController();

//         pageNumber === 1 ? setLoading(true) : setIsLoadingMore(true);

//         const requestBody = {
//           per_page: 20,
//           page: pageNumber,
//           reqType: "user",
//           admin_search: searchQuery || undefined,
//           orderBy: sortOrder === "newest" ? "DESC" : "ASC",
//         };

//         // Apply other filters
//         Object.entries(selectedFilters).forEach(([key, value]) => {
//           if (key === "otherFilters") return; // Skip direct otherFilters access

//           if (value?.length > 0) {
//             requestBody[key] = key === "year" ? Number(value) : value;
//           }
//         });

//         // Handle Other Filters parameters
//         Object.entries(selectedFilters).forEach(([param, value]) => {
//           if (
//             [
//               "HighlightArticle",
//               "CompMethodAdmin",
//               "doseComparison",
//               "drugComparison",
//               "pharmacokinetics",
//               "isERW",
//               "safetyofhydrogen",
//             ].includes(param)
//           ) {
//             requestBody[param] = "True"; // Send "True" for checked parameters
//           }
//         });

//         const response = await apiHandle.post(
//           "final-article-list",
//           requestBody,
//           {
//             signal: abortControllerRef.current.signal,
//           }
//         );

//         if (response.data.articles.length === 0) {
//           setHasMore(false);
//           setStudies([]);
//           setTotalArticles(response?.data?.total);
//         } else {
//           setTotalArticles(response?.data?.total);
//           setStudies((prevStudies) => {
//             return pageNumber === 1
//               ? response.data.articles
//               : [...prevStudies, ...response.data.articles];
//           });
//           setHasMore(response.data.current_page < response.data.last_page);
//         }
//       } catch (err) {
//         if (err.name !== "AbortError") {
//           setError("Error fetching data");
//         }
//       } finally {
//         setLoading(false);
//         setIsLoadingMore(false);
//         abortControllerRef.current = null;
//       }
//     },
//     [selectedFilters, debouncedSearchTerm, sortOrder]
//   );

//   // Combined effect for filters and pagination
//   useEffect(() => {
//     const timer = setTimeout(() => {
//       fetchStudies(page);
//     }, 100);

//     return () => {
//       clearTimeout(timer);
//       if (abortControllerRef.current) {
//         abortControllerRef.current.abort();
//       }
//     };
//   }, [page, selectedFilters, fetchStudies]);

//   // Utility function
//   const shallowCompare = (obj1, obj2) => {
//     const keys1 = Object.keys(obj1);
//     const keys2 = Object.keys(obj2);

//     if (keys1.length !== keys2.length) return false;

//     return keys1.every((key) =>
//       Array.isArray(obj1[key])
//         ? obj1[key].length === obj2[key]?.length &&
//         obj1[key].every((val, i) => val === obj2[key][i])
//         : obj1[key] === obj2[key]
//     );
//   };

//   const handleFilterChange = useCallback(
//     (filterName, value, checked, type = "checkbox") => {
//       setSelectedFilters((prev) => {
//         const newFilters = { ...prev };

//         // Special handling for Other Filters
//         if (filterName === "otherFilters") {
//           if (checked) {
//             newFilters[value] = "True"; // Set corresponding parameter to "True"
//           } else {
//             delete newFilters[value]; // Remove parameter when unchecked
//           }
//           return newFilters;
//         }

//         // Existing handling for other filters
//         if (type === "radio") {
//           newFilters[filterName] = value;
//         } else {
//           if (checked) {
//             newFilters[filterName] = [...(newFilters[filterName] || []), value];
//           } else {
//             newFilters[filterName] = (newFilters[filterName] || []).filter(
//               (item) => item !== value
//             );
//             if (newFilters[filterName].length === 0) {
//               delete newFilters[filterName];
//             }
//           }
//         }

//         return shallowCompare(prev, newFilters) ? prev : newFilters;
//       });
//       setPage(1);
//     },
//     []
//   );

//   // Optimized search handler
//   const handleSearch = useCallback(() => {
//     setPage(1);
//     fetchStudies(1, searchTerm);
//   }, [searchTerm, fetchStudies]);

//   useEffect(() => {
//     const fetchFilters = async () => {
//       try {
//         const response = await fetch(
//           "https://h2research.org/backend/public/api/get-fiters"
//         );
//         const result = await response.json();

//         if (result.status && result.data) {
//           const combinedData = {
//             ...result.data,
//             ...additionalFilters,
//           };

//           const transformedFilters = transformFilters(combinedData);
//           setFilters(transformedFilters);
//         }
//       } catch (error) {
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchFilters();
//   }, []);

//   useEffect(() => {
//     window.scrollTo(0, 0);
//   }, []);

//   const handleArticleDetails = (items) => {
//     navigate(`/ArticleDetails/${items.mhid}`);
//   };

//   const handleLoadMore = () => {
//     setIsLoadingMore(true);
//     setPage((prev) => prev + 1);
//   };

//   const filteredStudies = isSearchActive
//     ? searchResults // Search results use करें
//     : studies // Normal results use करें
//       .filter((study) => {
//         const yearFilter = selectedYear
//           ? study.publicData.year?.name?.toString() === selectedYear
//           : true;
//         return yearFilter;
//       })

//   const resetFilters = () => {
//     setSelectedFilters({});
//     fetchStudies(1);
//   };

//   const clearAuthorFilter = () => {
//     setSearchTerm("");
//     setDebouncedSearchTerm("");

//     // Remove author from selectedFilters
//     setSelectedFilters(prev => {
//       const newFilters = { ...prev };
//       delete newFilters.admin_search;
//       return newFilters;
//     });

//     // Clear URL parameter
//     const searchParams = new URLSearchParams(location.search);
//     searchParams.delete('author');
//     navigate(`${location.pathname}?${searchParams.toString()}`, { replace: true });

//     // Fetch studies without author filter
//     setPage(1);
//     fetchStudies(1, "");
//   };

//   const AuthorFilterDisplay = () => {
//     const searchParams = new URLSearchParams(location.search);
//     const authorParam = searchParams.get('author');

//     if (!authorParam) return null;

//     return (
//       <div className="mb-4 p-3 bg-blue-50 border-l-4 border-blue-400 rounded">
//         <div className="flex items-center justify-between">
//           <p className="text-sm text-blue-700">
//             <span className="font-medium">Filtering by author:</span> {authorParam}
//           </p>
//           <button
//             onClick={clearAuthorFilter}
//             className="text-blue-600 hover:text-blue-800 text-sm underline"
//           >
//             Clear filter
//           </button>
//         </div>
//       </div>
//     );
//   };
//   return (
//     <div className="bg-white">
//       <div className="max-w-[1200px] mx-auto p-4">
//         <div className="flex flex-col md:flex-row gap-6">
//           <div className="md:w-1/4">
//             <div className="sticky top-4">
//               <div className="h-0 md:h-[calc(100vh-150px)] lg:h-[calc(100vh-150px)] xl:h-[calc(100vh-150px)] overflow-y-auto">
//                 <FilterSidebar
//                   filters={filters}
//                   onFilterChange={handleFilterChange}
//                   onClearFilters={() => {
//                     setSelectedFilters({});
//                     fetchStudies(1);
//                   }}
//                   selectedFilters={selectedFilters}
//                 />
//               </div>
//             </div>
//           </div>

//           {/* Articles Listning */}
//           <div className="flex-1">
//             {/* <SearchBar searchTerm={searchTerm} setSearchTerm={setSearchTerm} /> */}
//             <SearchBar
//               searchTerm={searchTerm}
//               setSearchTerm={setSearchTerm}
//               onSearch={handleSearch}
//             />
//             <AuthorFilterDisplay />
//             <div
//               style={{
//                 display: "flex",
//                 justifyContent: "space-between",
//                 alignItems: "center",
//               }}
//             >
//               <p className="text-sm mb-4">Studies Found: {totalArticles}</p>
//               <div className="mb-4">
//                 <label htmlFor="sort-order" className="mr-2 text-sm">
//                   Sort by publication year:
//                 </label>
//                 <select
//                   id="sort-order"
//                   value={sortOrder}
//                   onChange={(e) => setSortOrder(e.target.value)}
//                   className="px-4 py-2 border rounded"
//                 >
//                   <option value="newest">Newest First</option>
//                   <option value="oldest">Oldest First</option>
//                 </select>
//               </div>
//             </div>

//             {loading && (
//               <div className="flex justify-center my-6">
//                 <Oval
//                   height={50}
//                   width={50}
//                   secondaryColor="#346896"
//                   color="#346896"
//                   visible={true}
//                 />
//               </div>
//             )}

//             {/* <div  className="space-y-4">
//               {filteredStudies?.length > 0 ? (
//                 filteredStudies?.map((study, index) => (
//                   <StudyCard
//                     key={index}
//                     study={study}
//                     onClick={() => handleArticleDetails(study)}
//                   />
//                 ))
//               ) : (
//                 !loading && <NoDataFound resetFilters={resetFilters} />
//               )}
//             </div>

//             {!isSearchActive && !loading && hasMore && (
//               <div  className="flex justify-center mt-6">
//                 <button
//                   onClick={handleLoadMore}
//                   disabled={isLoadingMore}
//                    className="px-6 py-2 bg-[#004C78] text-white rounded hover:bg-[#003355] disabled:opacity-75 flex items-center gap-2"
//                 >
//                   {isLoadingMore ? (
//                     <>
//                       <Oval
//                         height={20}
//                         width={20}
//                         secondaryColor="#fff"
//                         color="#fff"
//                         visible={true}
//                       />
//                       Loading...
//                     </>
//                   ) : (
//                     "Load More"
//                   )}
//                 </button>
//               </div>
//             )} */}
//             <div className="space-y-4">
//               {/* Show NoDataFound only when not loading and no studies */}
//               {!loading && filteredStudies?.length === 0 ? (
//                 <NoDataFound resetFilters={resetFilters} />
//               ) : (
//                 filteredStudies?.map((study, index) => (
//                   <StudyCard
//                     key={index}
//                     study={study}
//                     onClick={() => handleArticleDetails(study)}
//                   />
//                 ))
//               )}
//             </div>

//             {/* Load More Button */}
//             {!isSearchActive &&
//               !loading &&
//               hasMore &&
//               filteredStudies?.length > 0 && (
//                 <div className="flex justify-center mt-6">
//                   <button
//                     onClick={handleLoadMore}
//                     disabled={isLoadingMore}
//                     className="px-6 py-2 bg-[#004C78] text-white rounded hover:bg-[#003355] disabled:opacity-75 flex items-center gap-2"
//                   >
//                     {isLoadingMore ? (
//                       <>
//                         <Oval
//                           height={20}
//                           width={20}
//                           secondaryColor="#fff"
//                           color="#fff"
//                           visible={true}
//                         />
//                         Loading...
//                       </>
//                     ) : (
//                       "Load More"
//                     )}
//                   </button>
//                 </div>
//               )}

//             {!hasMore && studies.length > 0 && (
//               <div className="text-center mt-6 text-gray-500">
//                 All articles loaded
//               </div>
//             )}
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Articles;


import React, { useCallback, useEffect, useRef, useState } from "react";
import FilterSidebar from "../components/FilterSidebar/FilterSidebar";
import SearchBar from "../components/SearchBar/SearchBar";
import StudyCard from "../components/StudyCard/StudyCard";
import { Oval } from "react-loader-spinner";
import { useLocation, useNavigate } from "react-router-dom";
import { additionalFilters } from "../utils/constants";
import { transformFilters } from "../utils/helpers";
import { apiHandle } from "../config/apiHandle/apiHandle";
import NoDataFound from "../components/NoDataFound/NoDataFound";
import { MdClose, MdFilterList } from "react-icons/md";
import ContributeStudyCTA from "../components/ContributeStudyCTA/ContributeStudyCTA";

const Articles = () => {
  const navigate = useNavigate();
  const location = useLocation();
  // Get 'search' param from URL on initial load
  const initialSearchTerm = (() => {
    const params = new URLSearchParams(location.search);
    return params.get('search') || "";
  })();
  const [searchTerm, setSearchTerm] = useState(initialSearchTerm);
  const [searchTerms, setSearchTerms] = useState(initialSearchTerm ? [initialSearchTerm] : []);
  const [searchLogic, setSearchLogic] = useState("AND");
  const [selectedYear, setSelectedYear] = useState("");
  const [studies, setStudies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [selectedFilters, setSelectedFilters] = useState({});
  const [sortOrder, setSortOrder] = useState("newest");
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [totalArticles, setTotalArticles] = useState(0);
  const [isSearchActive, setIsSearchActive] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState("");

  const abortControllerRef = useRef(null);

  // Enhanced URL parameter parsing - only for initial page load
  useEffect(() => {
    console.log('Articles useEffect triggered', { 
      search: location.search, 
      state: location.state 
    });
    
    const searchParams = new URLSearchParams(location.search);
    const params = {};
    
    // Check if we have search data from navigation state (from ArticleDetails)
    const navigationState = location.state;
    if (navigationState && navigationState.fromArticleDetails && navigationState.searchTerms) {
      console.log('Navigation state detected:', navigationState);
      
      // Handle search data from ArticleDetails navigation
      const { searchTerms: navSearchTerms, searchLogic: navSearchLogic } = navigationState;
      
      console.log('Setting search state:', { navSearchTerms, navSearchLogic });
      
      // Set all search-related state immediately and synchronously
      setSearchTerms(navSearchTerms);
      setSearchTerm(navSearchTerms[0] || "");
      setSearchLogic(navSearchLogic || "AND");
      setDebouncedSearchTerm(navSearchTerms);
      setPage(1);
      
      // Note: Don't set admin_search in selectedFilters - fetchStudies will handle searchQuery as array
      
      // Clear the navigation state to prevent it from persisting
      window.history.replaceState({}, '', location.pathname);
      
      // Trigger search with a slight delay to ensure state is set
      setTimeout(() => {
        fetchStudies(1, navSearchTerms);
      }, 50);
      
      return; // Exit early to avoid URL parameter processing
    }
    
    // Get author parameter from URL and set it in search term (for initial load only)
    const authorParam = searchParams.get('author');
    if (authorParam && authorParam.trim()) {
      setSearchTerm(authorParam);
      setSearchTerms([authorParam]);
      setDebouncedSearchTerm([authorParam]);
      params.admin_search = authorParam;
    }

    // Get search parameter from URL (for initial load only)
    const searchParam = searchParams.get('search');
    if (searchParam && searchParam.trim() && !authorParam) {
      // Split search param by spaces to handle multiple terms passed as single param
      const terms = searchParam.split(' ').filter(term => term.trim());
      if (terms.length > 0) {
        setSearchTerm(terms[0]); // Set first term as main search term
        setSearchTerms(terms); // Set all terms
        setDebouncedSearchTerm(terms);
        params.admin_search = searchParam;
      }
    }

    // Get logic parameter from URL to preserve search mode (for initial load only)
    const logicParam = searchParams.get('logic');
    if (logicParam && (logicParam === "AND" || logicParam === "OR")) {
      setSearchLogic(logicParam);
    }

    // If no search parameters exist, ensure search state is cleared (only on initial load)
    if (!authorParam && !searchParam) {
      setSearchTerm("");
      setSearchTerms([]);
      setDebouncedSearchTerm([]);
      setSearchLogic("AND"); // Reset to default
    }

    // Map URL parameters to request body fields
    const paramMappings = {
      study: "studyType",
      specie: "species",
      researchTopic: "researchtopic",
      organ: "organ",
      year: "year",
      author: "admin_search",
      marker: "marker",
      category: "category",
      authors: "authors",
      country: "country",
      system: "system",
      administration_methods: "administration_methods",
      disease : "disease"
    };

    // Iterate through all search parameters
    searchParams.forEach((value, key) => {
      if (paramMappings[key]) {
        const mappedKey = paramMappings[key];
        if (
          [
            "studyType",
            "species",
            "researchtopic",
            "organ",
            "marker",
            "category",
            "authors",
            "country",
            "system",
            "administration_methods",
            "disease"
          ].includes(mappedKey)
        ) {
          params[mappedKey] = searchParams.getAll(key);
        } else if (["year", "admin_search"].includes(mappedKey)) {
          params[mappedKey] = value;
        }
      }
    });

    // Update selected filters with parsed params
    setSelectedFilters((prev) => ({
      ...prev,
      ...params,
    }));

    // If author parameter exists, trigger search immediately
    if (authorParam) {
      setPage(1);
      setTimeout(() => {
        fetchStudies(1, [authorParam]);
      }, 100);
    }
  }, [location.search, location.state]);

  // Debounced search effect
  useEffect(() => {
    const timer = setTimeout(() => {
      // No need to combine search terms here since we'll send them as array
      setDebouncedSearchTerm(searchTerms.length > 0 ? searchTerms : [searchTerm].filter(Boolean));
    }, 500);

    return () => clearTimeout(timer);
  }, [searchTerm, searchTerms, searchLogic]);

  // Memoized fetch function
  const fetchStudies = useCallback(
    async (pageNumber = 1, searchQuery = debouncedSearchTerm) => {
      try {
        if (abortControllerRef.current) {
          abortControllerRef.current.abort();
        }
        abortControllerRef.current = new AbortController();

        pageNumber === 1 ? setLoading(true) : setIsLoadingMore(true);

        const requestBody = {
          per_page: 20,
          page: pageNumber,
          reqType: "user",
          orderBy: sortOrder === "newest" ? "DESC" : "ASC",
        };

        // Handle search terms - send as array if we have search terms
        if (searchQuery && Array.isArray(searchQuery) && searchQuery.length > 0) {
          requestBody.admin_search = searchQuery;
        } else if (searchQuery && typeof searchQuery === 'string' && searchQuery.trim()) {
          // Fallback for single string search
          requestBody.admin_search = [searchQuery.trim()];
        }
        
        // Always send isAnd for search/filter logic (applies to both search terms and filters)
        requestBody.isAnd = searchLogic === "AND";

        // Apply other filters
        Object.entries(selectedFilters).forEach(([key, value]) => {
          if (key === "otherFilters") return;

          if (value?.length > 0) {
            requestBody[key] = key === "year" ? Number(value) : value;
          }
        });

        // Handle Other Filters parameters
        Object.entries(selectedFilters).forEach(([param, value]) => {
          if (
            [
              "HighlightArticle",
              "CompMethodAdmin",
              "doseComparison",
              "drugComparison",
              "pharmacokinetics",
              "isERW",
              "safetyofhydrogen",
            ].includes(param)
          ) {
            requestBody[param] = "True";
          }
        });

        const response = await apiHandle.post(
          "final-article-list-main",
          requestBody,
          {
            signal: abortControllerRef.current.signal,
          }
        );

        if (response.data.articles.length === 0) {
          setHasMore(false);
          setStudies([]);
          setTotalArticles(response?.data?.total);
        } else {
          setTotalArticles(response?.data?.total);
          setStudies((prevStudies) => {
            return pageNumber === 1
              ? response.data.articles
              : [...prevStudies, ...response.data.articles];
          });
          setHasMore(response.data.current_page < response.data.last_page);
        }
      } catch (err) {
        if (err.name !== "AbortError") {
          setError("Error fetching data");
        }
      } finally {
        setLoading(false);
        setIsLoadingMore(false);
        abortControllerRef.current = null;
      }
    },
    [selectedFilters, debouncedSearchTerm, sortOrder, searchLogic]
  );

  // Combined effect for filters and pagination
  useEffect(() => {
    const timer = setTimeout(() => {
      fetchStudies(page);
    }, 100);

    return () => {
      clearTimeout(timer);
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, [page, selectedFilters, fetchStudies]);

  // Utility function
  const shallowCompare = (obj1, obj2) => {
    const keys1 = Object.keys(obj1);
    const keys2 = Object.keys(obj2);

    if (keys1.length !== keys2.length) return false;

    return keys1.every((key) =>
      Array.isArray(obj1[key])
        ? obj1[key].length === obj2[key]?.length &&
        obj1[key].every((val, i) => val === obj2[key][i])
        : obj1[key] === obj2[key]
    );
  };

  const handleFilterChange = useCallback(
    (filterName, value, checked, type = "checkbox") => {
      setSelectedFilters((prev) => {
        const newFilters = { ...prev };

        if (filterName === "otherFilters") {
          if (checked) {
            newFilters[value] = "True";
          } else {
            delete newFilters[value];
          }
          return newFilters;
        }

        if (type === "radio") {
          newFilters[filterName] = value;
        } else {
          if (checked) {
            newFilters[filterName] = [...(newFilters[filterName] || []), value];
          } else {
            newFilters[filterName] = (newFilters[filterName] || []).filter(
              (item) => item !== value
            );
            if (newFilters[filterName].length === 0) {
              delete newFilters[filterName];
            }
          }
        }

        return shallowCompare(prev, newFilters) ? prev : newFilters;
      });
      setPage(1);
    },
    []
  );

  // Optimized search handler
  const handleSearch = useCallback(() => {
    setPage(1);
    const searchArray = searchTerms.length > 0 ? searchTerms : [searchTerm].filter(Boolean);
    fetchStudies(1, searchArray);
  }, [searchTerm, searchTerms, searchLogic, fetchStudies]);

  useEffect(() => {
    const fetchFilters = async () => {
      try {
        const response = await fetch(
          "https://h2research.org/backend/public/api/get-fiters"
        );
        const result = await response.json();
        //

        if (result.status && result.data) {
          const combinedData = {
            ...result.data,
            ...additionalFilters,
          };



          const transformedFilters = transformFilters(combinedData);
          setFilters(transformedFilters);
        }
      } catch (error) {
      } finally {
        setLoading(false);
      }
    };

    fetchFilters();
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleArticleDetails = (items) => {
    navigate(`/ArticleDetails/${items.mhid}`);
  };

  const handleLoadMore = () => {
    setIsLoadingMore(true);
    setPage((prev) => prev + 1);
  };

  // Complete clear all functionality
  const clearAllFilters = () => {
    // Clear all state
    setSearchTerm("");
    setSearchTerms([]);
    setDebouncedSearchTerm([]);
    setSelectedFilters({});
    setSelectedYear("");
    setSortOrder("newest");
    setSearchLogic("AND");
    setPage(1);
    
    // Use replaceState to immediately clear URL without navigation
    window.history.replaceState({}, '', location.pathname);
    
    // Fetch fresh data
    fetchStudies(1, []);
  };

  // Clear specific filter functionality
  const clearSpecificFilter = (filterType, filterValue = null) => {
    if (filterType === 'search') {
      if (filterValue) {
        // Remove specific search term
        const newTerms = searchTerms.filter(term => term !== filterValue);
        setSearchTerms(newTerms);
        if (newTerms.length === 0) {
          setSearchTerm("");
          setDebouncedSearchTerm([]);
          setSearchLogic("AND"); // Reset to default when no search terms
        }
      } else {
        // Clear all search terms
        setSearchTerm("");
        setSearchTerms([]);
        setDebouncedSearchTerm([]);
        setSearchLogic("AND"); // Reset to default when clearing all search
      }
      
      setSelectedFilters(prev => {
        const newFilters = { ...prev };
        delete newFilters.admin_search;
        return newFilters;
      });

      const searchParams = new URLSearchParams(location.search);
      searchParams.delete('author');
      searchParams.delete('search');
      searchParams.delete('logic'); // Also remove the logic parameter
      
      // Use replaceState to immediately update URL without triggering navigation
      const newUrl = searchParams.toString() ? 
        `${location.pathname}?${searchParams.toString()}` : 
        location.pathname;
      window.history.replaceState({}, '', newUrl);
      
      const combinedSearchTerm = filterValue 
        ? searchTerms.filter(term => term !== filterValue)
        : [];
      
      // Only fetch with search terms if there are any, otherwise fetch without search
      if (combinedSearchTerm.length > 0) {
        fetchStudies(1, combinedSearchTerm);
      } else {
        fetchStudies(1, []); // Pass empty array which will not add admin_search to request
      }
    } else {
      setSelectedFilters(prev => {
        const newFilters = { ...prev };
        
        if (filterValue) {
          // Remove specific value from array filter
          if (Array.isArray(newFilters[filterType])) {
            newFilters[filterType] = newFilters[filterType].filter(item => item !== filterValue);
            if (newFilters[filterType].length === 0) {
              delete newFilters[filterType];
            }
          }
        } else {
          // Remove entire filter
          delete newFilters[filterType];
        }
        
        return newFilters;
      });
      
      setPage(1);
    }
  };

  // Get active filters for display
  const getActiveFilters = () => {
    const activeFilters = [];
    
    // Check for search terms (directly from state, not URL)
    searchTerms.forEach((term, index) => {
      activeFilters.push({
        type: 'search',
        label: `Search Term ${index + 1}`,
        value: term,
        key: `search-${index}`
      });
    });

    // Check for other filters
    Object.entries(selectedFilters).forEach(([key, value]) => {
      if (key === 'admin_search') return; // Skip search filters, handled above
      
      if (Array.isArray(value) && value.length > 0) {
        value.forEach(item => {
          activeFilters.push({
            type: key,
            label: key.charAt(0).toUpperCase() + key.slice(1),
            value: item,
            key: `${key}-${item}`
          });
        });
      } else if (value && !Array.isArray(value)) {
        activeFilters.push({
          type: key,
          label: key.charAt(0).toUpperCase() + key.slice(1),
          value: value,
          key: key
        });
      }
    });

    return activeFilters;
  };

  const filteredStudies = isSearchActive
    ? searchResults
    : studies.filter((study) => {
        const yearFilter = selectedYear
          ? study.publicData.year?.name?.toString() === selectedYear
          : true;
        return yearFilter;
      });

  const resetFilters = () => {
    clearAllFilters();
  };

  const activeFilters = getActiveFilters();

  // Active Filters Display Component
  const ActiveFiltersDisplay = () => {
    if (activeFilters.length === 0) return null;

    const searchFilters = activeFilters.filter(filter => filter.type === 'search');
    const otherFilters = activeFilters.filter(filter => filter.type !== 'search');

    return (
      <div className="mb-4 p-4 bg-gray-50 border border-gray-200 rounded-lg">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-gray-700 flex items-center">
            <MdFilterList className="w-4 h-4 mr-2" />
            Active Filters ({activeFilters.length})
            {/* Global Search Mode Indicator */}
            {activeFilters.length > 0 && (
              <span className="ml-3 px-2 py-1 text-xs rounded-full font-medium bg-blue-100 text-primary">
                {searchLogic === "OR" ? "MATCH ANY TERM" : "MATCH ALL TERMS"}
              </span>
            )}
          </h3>
          <button
            onClick={clearAllFilters}
            className="text-red-600 hover:text-red-800 text-sm font-medium flex items-center transition-colors"
          >
            <MdClose className="w-4 h-4 mr-1" />
            Clear All
          </button>
        </div>
        
        {/* Search Mode Explanation */}
        {activeFilters.length > 0 && (
          <div className="mb-3 p-2 rounded text-xs bg-blue-50 text-primary border border-blue-200">
            <strong>{searchLogic === "OR" ? "Match Any Term" : "Match All Terms"}:</strong> {' '}
            {searchLogic === "OR" 
              ? "Showing articles that contain any of your search terms"
              : "Showing only articles that contain all of your search terms"
            }
          </div>
        )}
        
        {/* Search Terms */}
        {searchFilters.length > 0 && (
          <div className="mb-3">
            <div className="flex items-center flex-wrap gap-2">
              <span className="text-xs text-gray-600 mr-2 font-medium">Search Terms:</span>
              {searchFilters.map((filter, index) => (
                <div key={filter.key} className="flex items-center">
                  <div className="flex items-center border rounded-full px-3 py-1.5 bg-white border-blue-200">
                    <span className="mr-2 text-xs font-medium text-primary">
                      {filter.value}
                    </span>
                    <button
                      onClick={() => clearSpecificFilter(filter.type, filter.value)}
                      className="text-primary hover:text-red-600 transition-colors"
                      title="Remove search term"
                    >
                      <MdClose className="w-3 h-3" />
                    </button>
                  </div>
                  {index < searchFilters.length - 1 && (
                    <span className="mx-2 px-2 py-1 text-xs rounded font-bold bg-blue-100 text-primary">
                      {searchLogic === "OR" ? "or" : "and"}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Other Filters */}
        {otherFilters.length > 0 && (
          <div>
            <span className="text-xs text-gray-600 mr-2 font-medium">Selected Filters:</span>
            <div className="flex flex-wrap gap-2 mt-2">
              {otherFilters.map((filter) => (
                <div
                  key={filter.key}
                  className="flex items-center bg-white border border-blue-200 rounded-full px-3 py-1.5"
                >
                  <span className="text-primary mr-2 text-xs font-medium">
                    {filter.value}
                  </span>
                  <button
                    onClick={() => clearSpecificFilter(filter.type, filter.value)}
                    className="text-primary hover:text-red-600 transition-colors"
                    title="Remove filter"
                  >
                    <MdClose className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="bg-white">
      <div className="max-w-[1200px] mx-auto p-2 sm:p-4">
        <div className="flex flex-col lg:flex-row gap-4 lg:gap-6">
          <div className="lg:w-1/4">
            <div className="sticky top-4">
              <div className="h-0 lg:h-[calc(100vh-150px)] overflow-y-auto">
                <FilterSidebar
                  filters={filters}
                  onFilterChange={handleFilterChange}
                  onClearFilters={clearAllFilters}
                  selectedFilters={selectedFilters}
                />
              </div>
            </div>
          </div>

          <div className="flex-1">
            <div className="mb-4">
              <SearchBar
                searchTerm={searchTerm}
                setSearchTerm={setSearchTerm}
                onSearch={handleSearch}
                searchTerms={searchTerms}
                setSearchTerms={setSearchTerms}
                searchLogic={searchLogic}
                setSearchLogic={setSearchLogic}
              />
            </div>
            
            <ActiveFiltersDisplay />

            <div className="flex flex-col xs:flex-row justify-between items-start xs:items-center mb-4 gap-2">
              <p className="text-sm">Studies Found: {totalArticles}</p>
              <div className="mb-4">
                <label htmlFor="sort-order" className="mr-2 text-sm">
                  Sort by publication year:
                </label>
                <select
                  id="sort-order"
                  value={sortOrder}
                  onChange={(e) => setSortOrder(e.target.value)}
                  className="px-4 py-2 border rounded"
                >
                  <option value="newest">Newest First</option>
                  <option value="oldest">Oldest First</option>
                </select>
              </div>
            </div>

            {loading && (
              <div className="flex justify-center my-6">
                <Oval
                  height={50}
                  width={50}
                  secondaryColor="#346896"
                  color="#346896"
                  visible={true}
                />
              </div>
            )}

            <div className="space-y-4">
              {!loading && filteredStudies?.length === 0 ? (
                <NoDataFound resetFilters={resetFilters} />
              ) : (
                filteredStudies?.map((study, index) => (
                  <StudyCard
                    key={index}
                    study={study}
                    onClick={() => handleArticleDetails(study)}
                  />
                ))
              )}
            </div>

            {!isSearchActive &&
              !loading &&
              hasMore &&
              filteredStudies?.length > 0 && (
                <div className="flex justify-center mt-6">
                  <button
                    onClick={handleLoadMore}
                    disabled={isLoadingMore}
                    className="px-6 py-2 bg-[#004C78] text-white rounded hover:bg-[#003355] disabled:opacity-75 flex items-center gap-2"
                  >
                    {isLoadingMore ? (
                      <>
                        <Oval
                          height={20}
                          width={20}
                          secondaryColor="#fff"
                          color="#fff"
                          visible={true}
                        />
                        Loading...
                      </>
                    ) : (
                      "Load More"
                    )}
                  </button>
                </div>
              )}

            {!hasMore && studies.length > 0 && (
              <div className="text-center mt-6 text-gray-500">
                All articles loaded
              </div>
            )}

          {/* Contribute CTA */}
          <ContributeStudyCTA />
          </div>
          {/* add a button contribute by adding the study */}
     
        
         
        </div>
      </div>
    </div>
  );
};

export default Articles;